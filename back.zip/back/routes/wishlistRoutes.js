const express = require('express');
const router = express.Router();
const wishlistController = require('../controllers/wishlistController');

// Routes for wishlist
router.post('/', wishlistController.addToWishlist);
router.get('/', wishlistController.getWishlist);
router.delete('/:id', wishlistController.removeFromWishlist);
router.delete('/', wishlistController.clearWishlist);

module.exports = router;
