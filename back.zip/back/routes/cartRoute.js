const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');
 
// Route to get the current cart
router.get('/', cartController.getCart);
 
// Route to add an item to the cart
router.post('/add', cartController.addToCart);
 
// Route to remove an item from the cart
router.delete('/remove', cartController.removeFromCart);
 
// Route to clear the entire cart
router.delete('/clear', cartController.clearCart);
 
module.exports = router;

