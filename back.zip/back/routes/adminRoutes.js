const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');

// Middleware for debugging (logs requests to console)
router.post('/register', (req, res, next) => {
    console.log('Register endpoint hit');
    next();
});

router.post('/login', (req, res, next) => {
    console.log('Login endpoint hit');
    next();
});

// Actual route handlers
router.post('/register', adminController.registerAdmin);
router.post('/login', adminController.loginAdmin);

module.exports = router;
